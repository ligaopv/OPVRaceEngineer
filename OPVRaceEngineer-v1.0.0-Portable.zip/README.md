﻿# 🏎️ OPV Race Engineer

![OPV Race Engineer Banner](app_cover.png)

**OPV Race Engineer** é um aplicativo de engenharia de pista, telemetria em tempo real e cálculo de estratégia desenvolvido especialmente para pilotos virtuais nos principais simuladores modernos:

- 🏁 **Assetto Corsa EVO**
- 🏁 **Assetto Corsa Competizione (ACC)**
- 🏁 **Le Mans Ultimate (LMU)**

---

## 🚀 Principais Recursos

- ⏱️ **Cálculo de Combustível Inteligente:** Estimativa precisa de consumo médio por volta (L/v), combustível no tanque e total exato para abastecer até o final da prova com voltas de segurança.
- 🎯 **Delta de Pressão Alvo (PSI):** Cálculo roda a roda (Dianteira Esquerda/Direita, Traseira Esquerda/Direita) para calibragem exata a frio, sugerindo o acerto perfeito após o stint.
- 🛑 **Pit Wall & Estratégia:** Regras interativas de troca de pneus (Obrigatório / Opcional / Não) e reabastecimento (Obrigatório / Programado / Livre / Não) clicáveis e intuitivas.
- 🔔 **Alerta Sonoro de Janela de Box:** Beep sonoro configurável nos minutos finais da janela de pit stop.
- 🌍 **Multi-idiomas com Auto-detecção:** Suporte nativo a 7 idiomas com botão seletor de bandeiras vetorizadas:
  - 🇧🇷 Português (Brasil)
  - 🇵🇹 Português (Portugal)
  - 🇺🇸 English
  - 🇪🇸 Español
  - 🇮🇹 Italiano
  - 🇩🇪 Deutsch
  - 🇫🇷 Français
- ⚡ **Zero Dependências Pesadas:** Desenvolvido nativamente em C# (.NET Framework nativo do Windows), sem instaladores complexos ou impacto na taxa de quadros (FPS) do simulador.

---

## 🎁 Modelo de Distribuição & Comunidade

O **OPV Race Engineer** adota o modelo **Freemium Comunitário**:

- **Gratuito para a Comunidade:** Acesso 100% gratuito para quem apoia e acompanha nossos canais:
  - 📺 **YouTube:** [@ligaopv](https://www.youtube.com/@ligaopv)
  - 📸 **Instagram:** [@ligaopv](https://www.instagram.com/ligaopv)
  - 🏁 **The SimGrid:** [ligaopv](https://www.thesimgrid.com/communities/liga-opv-oficina-piloto-virtual)
  - 🌐 **Portal Oficial:** [ligaopv.com.br](https://ligaopv.com.br/)
- **Licença Comercial / Apoio Avulso:** Pilotos que desejarem obter licenças diretas ou apoiar o desenvolvimento contínuo podem adquirir através do portal oficial ou entrar em contato pelo e-mail **contato@ligaopv.com.br**.

---

## 🛠️ Como Compilar o Código-Fonte

Não é necessário instalar o Visual Studio completo para compilar! O projeto usa o compilador C# nativo do Windows.

1. Clone o repositório:
   ```bash
   git clone https://github.com/SEU_USUARIO/OPVRaceEngineer.git
   cd OPVRaceEngineer
   ```
2. Execute o script de compilação:
   ```cmd
   build.bat
   ```
3. O executável `OPVRaceEngineer.exe` será gerado instantaneamente na mesma pasta.

---

## 📞 Contato & Créditos

- **Desenvolvido por:** TH Leonels
- **Organização:** Oficina Piloto Virtual (Liga OPV)
- **Website:** [https://ligaopv.com.br/](https://ligaopv.com.br/)
- **E-mail:** [contato@ligaopv.com.br](mailto:contato@ligaopv.com.br)
